Simple React Seed Project
==

Just clone it, cd into it, npm install it, and npm start it.

```
git clone git https://github.com/leebrandt/simple-react-seed.git [some new project name]
cd [some new project name]
npm i
npm start
```