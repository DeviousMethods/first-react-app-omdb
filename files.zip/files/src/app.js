import React from 'react';
import {render} from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import Layout from './components/common/Layout';
import HomePage from './components/home/HomePage';
import FavoritesPage from './components/user/FavoritesPage';
import RegisterPage from './components/user/RegisterPage';
import LoginPage from './components/user/LoginPage';
import SearchMovies from './components/common/SearchMovies';
import MoviePage from './components/common/MoviePage';
import '../scss/site.scss';

render(
  <Router>
    <Layout>
      <Switch>
          <Route exact path="/" component={HomePage}/>
          <Route exact path="/favorites" component={FavoritesPage}/>
          <Route exact path="/register" component={RegisterPage}/>
          <Route exact path="/login" component={LoginPage}/>
          <Route exact path="/movie/:movieId" component={MoviePage} />
          <Route component={SearchMovies} />
      </Switch>
    </Layout>
  </Router>,
  document.getElementById('app')
)
