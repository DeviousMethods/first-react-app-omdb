import React, {Component} from 'react';
import SearchMovies from './../common/SearchMovies';
import RecentMovies from './../common/RecentMovies';

export default class HomePage extends Component{
  render(){
    return (
    <div className="container">
      <SearchMovies />
        <div>
          <RecentMovies />
        </div>
    </div>
    );
  }
}
