import React, {Component} from 'react'
import fire from '../../fire.js'
import firebase from 'firebase'

export default class LoginPage extends Component{

  login = e => {
    e.preventDefault();
    var provider = new firebase.auth.GoogleAuthProvider();
    fire.auth().signInWithPopup(provider);
  }
  logout = e => {
    e.preventDefault();
    fire.auth().signOut();
  }
  render(){
    return (
    <div className="container">
      <h1>Login</h1>
      <p>
        Login to save your favorite movies!
        <button onClick={this.login}>Login</button>
        <button onClick={this.logout}>Logout</button>
      </p>
    </div>
    )
  }
}
