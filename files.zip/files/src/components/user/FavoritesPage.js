import React, {Component} from 'react'

export default class Favorites extends Component{
  render(){
    return (
    <div className="container">
      <h1>Favorite Movies</h1>
      <p>
        This page lets you manage your favorite movies.
      </p>
    </div>
    )
  }
}
