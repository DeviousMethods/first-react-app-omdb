import React, {Component} from 'react'

export default class RegisterPage extends Component{
  render(){
    return (
    <div className="container">
      <h1>Register</h1>
      <p>
        Ready to sign up? Lets get started!
      </p>
    </div>
    )
  }
}
