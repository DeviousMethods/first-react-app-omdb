import React, { Component } from 'react';
import * as axios from 'axios';
import Movie from './Movie';

export default class RecentMovies extends Component {


  constructor(props) {
    super(props);
    this.state = { loading: true, movies: [] };
  }

  componentWillMount () {
    this.loadMovies();
  }

  loadMovies = () => {
      axios.get('http://www.omdbapi.com/?apikey=583ef338', {
        params: {
           s: 'a',
           type: 'movie',
           y: '2017',
           r:'json'}
        }
      ).then(response => {
          // this.setState({ loading: false , movies: movies });
          var movies = response.data.Search;
          this.setState({ loading: false , movies });
      });
  }

  render() {
    if(this.state.loading){
      return (
        <div className="panel panel-default">
        <div className="panel-heading">
          <h3 className="panel-title">{this.props.title}</h3>
        </div>
        <div className="panel-body">
          loading
        </div>
      </div>);
    } else {
      var movies = this.state.movies.map((movie, i) => {
        return (<Movie movie={movie} key={i} />);
      });

      return (
        <div className="panel panel-default">
          <div className="panel-heading">
            <h3 className="panel-title">{this.props.title}</h3>
          </div>
          <div className="panel-body">
            {movies}
          </div>
        </div>
      );
    }
  }
}
