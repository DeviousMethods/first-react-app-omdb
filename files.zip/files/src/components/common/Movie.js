import React from 'react';
import * as axios from 'axios';
import { Link, withRouter } from 'react-router-dom';

class Movie extends React.Component {

  state = {
    details: {}
  }

  componentWillMount(){
    axios.get('http://www.omdbapi.com/?apikey=583ef338', {
      params: {
         i: this.props.movie.imdbID,
         plot: 'short',
         r:'json'}
      }
    ).then(response => {
        this.setState({details: response.data });
    });
  }

  render(){
    let { movie } = this.props;
    // let movie = this.props.movie;

    if(!movie) return <div>Loading...</div>;

    return (
      <div>
      <table className="search-results">
        <tbody>
          <tr>
            <td><img src={movie.Poster} /></td>
            <td><h1><Link to={`/movie/${movie.imdbID}`}>{movie.Title}</Link></h1>
            <h4>{movie.Year}</h4>
            <h4>{movie.Released}</h4>
            <p>{this.state.details.Plot}</p></td>
          </tr>
        </tbody>
      </table>
      </div>
    );
  }
};

export default withRouter( Movie );
