import React, { Component, PropTypes } from 'react';
import * as axios from 'axios';
import Movie from './Movie';
import { withRouter } from 'react-router-dom'


class SearchMovies extends Component {

  constructor(props) {
    super(props);
    this.state = { movies: [], name: '' };
  }
  componentWillMount(){
    let name = this.props.location.pathname.substr(1);
    if(name) this.searchMovie(name);
  }

  searchMovie = (name) => {
    // if(!name) { name = this.props.location.pathname.substr(1) }
    axios.get('http://www.omdbapi.com/?i=tt3896198&apikey=583ef338&s='+name, {
      params: {
         t: name,
         plot: 'full',
         r:'json',
        }
      }
    ).then(response => {
        //let data =
          /*title: response.data.Search[0].Title,
          year: response.data.Search[0].Year,
          released: <div><b>Released:</b> {response.data.Released}</div>,
          plot: <div><b>Plot: </b>{response.data.Plot}</div>,
          id: response.data.imdbID,
          image: response.data.Poster*/
        //};
        console.log('response', response);
        var movies = response.data.Search || [response.data];
      this.setState({ movies });
    });
  };

  handleChange =  (event) => {
    this.setState({name: event.target.value});
  };

  onSubmit = e => {
    e.preventDefault();
    this.searchMovie(this.state.name);
  }

  render() {
    return (
        <div className="panel panel-default">
          <div className="panel-body">
            <div className="col-xs-12" >
              <form className="form-group" onSubmit={this.onSubmit}>
                <label htmlFor="title">Search Movies by Name</label>
                <input type="text" className="form-control" id="title" placeholder="Movie Name" onChange={this.handleChange}/>
                <input className="btn-primary" type="submit" value="Search"  />
              </form>
            </div>
            { this.state.movies.map( movie => {
                return <Movie key={movie.imdbID+movie.Poster} movie={movie}  />
              } )

            }

          </div>
        </div>
      );
    }
  }



export default withRouter( SearchMovies )
