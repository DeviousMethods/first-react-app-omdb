import React from 'react';
import * as axios from 'axios';
import { Link, withRouter } from 'react-router-dom';

class MoviePage extends React.Component {

  state = {
    details: null
  }

  componentWillMount(){
    axios.get('http://www.omdbapi.com/?apikey=583ef338', {
      params: {
         i: this.props.match.params.movieId,
         plot: 'full',
         r:'json'}
      }
    ).then(response => {
        this.setState({details: response.data });
    });
  }

  render(){
    //let { movie } = this.props;
    // let movie = this.props.movie;

    let {details} = this.state;
    if(!details) return <div>Loading...</div>;

    return (
      <div>
      <table className="search-results">
        <tbody>
          <tr>
            <td><img src={details.Poster} /></td>
            <td><h1><Link to={ details.Title }>{details.Title}</Link></h1>
            <h4>{details.Year}</h4>
            <h4>{details.Released}</h4>
            <p>{details.Runtime}</p>
            <p>{details.Genre}</p>
            <p>{details.Director}</p>
            <p>{details.Actors}</p>
            <p>{details.Plot}</p>
            <p>{details.Awards}</p>
            <p><b>Ratings:</b>{ !!details.Ratings && !!details.Ratings.length && details.Ratings.map( r => <span key={r.Source}>
              <br />
              Source: {r.Source}
              <br />
              Rating: {r.Value} <br />
              </span>)}</p>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
    );
  }
};

export default withRouter( MoviePage );
