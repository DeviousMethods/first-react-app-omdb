import React from 'react';

import Navigation from './Navigation';

import firebase from '../../fire.js'

class Layout extends React.Component{
  componentWillMount(){
    firebase.auth().onAuthStateChanged( user =>{

      console.log('User changed to', user)
    })
  }
  render(){
    return(
      <section className="page">
        <Navigation/>
        <section>
          {this.props.children}
        </section>
      </section>
    );
  }
}

export default Layout
