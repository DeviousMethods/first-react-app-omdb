import firebase from 'firebase'
var config = {
   apiKey: "AIzaSyBOq7pVCcMWBL8TkpdtcwLzH0FJOuJe5b4",
   authDomain: "omdbapp-ff143.firebaseapp.com",
   databaseURL: "https://omdbapp-ff143.firebaseio.com",
   projectId: "omdbapp-ff143",
   storageBucket: "omdbapp-ff143.appspot.com",
   messagingSenderId: "182741842283"
 };
var fire = firebase.initializeApp(config);
export default fire;
